//
//  PrimaryButtonStyle.swift
//  TraningSwiftUIApp
//
//  Created by Vivek_Ios on 26/04/26.
//

import Foundation
import SwiftUI
struct PrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .frame(maxWidth: .infinity, minHeight: 40)
            .background(Color.white)
            .cornerRadius(8)
            .foregroundColor(.black)
            .font(.system(size: 17, weight: .bold))
            .opacity(configuration.isPressed ? 0.7 : 1.0) // ✅ Press effect
    }
}
