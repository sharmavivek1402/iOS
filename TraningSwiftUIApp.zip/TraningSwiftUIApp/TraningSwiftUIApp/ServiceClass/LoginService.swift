//
//  LoginService.swift
//  TraningSwiftUIApp
//
//  Created by Vivek_Ios on 29/04/26.
//

import Foundation

protocol LoginServiceProtocol {
    func login(request: LoginRequest) async throws -> LoginResponse
}

class LoginAPIService: LoginServiceProtocol {
    func login(request: LoginRequest) async throws -> LoginResponse {
        guard let url = URL(string: "https://yourapi.com/login") else {
            throw URLError(.badURL)
        }
        
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = try JSONEncoder().encode(request)
        
        let (data, response) = try await URLSession.shared.data(for: urlRequest)
        
        guard let httpResponse = response as? HTTPURLResponse,
              200..<300 ~= httpResponse.statusCode else {
            throw URLError(.badServerResponse)
        }
        
        return try JSONDecoder().decode(LoginResponse.self, from: data)
    }
}
