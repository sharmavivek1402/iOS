//
//  NavigationManager.swift
//  FitFuluencerSwiftUI
//
//  Created by Vivek_Ios on 22/03/25.
//

import Foundation
import SwiftUI
import Combine

class NavigationManager: ObservableObject {
    
    @Published var path: [AnyView] = []
    func push<V: View>(_ view: V) {
        path.append(AnyView(view))
    }

    func pop() {
        path.removeLast()
    }
    
    func popToRoot() {
        path.removeAll()
    }
}
