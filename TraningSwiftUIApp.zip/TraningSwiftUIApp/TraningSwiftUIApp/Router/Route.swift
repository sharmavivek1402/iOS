//
//  Route.swift
//  FitFuluencerSwiftUI
//
//  Created by Vivek_Ios on 24/03/25.
//

import Foundation
import SwiftUI
import UIKit
import Combine

enum Route: Hashable {

    case login
    case signUp
    case welcome
    case creteAccount
    case home
}


final class Router: ObservableObject {

    @Published var navigationPath = NavigationPath() {
        willSet(newPath) {
            if newPath.count < navigationPath.count - 1 {
                let animation = CATransition()
                animation.isRemovedOnCompletion = true
                animation.type = .moveIn
                animation.duration = 0.4
                animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
                Self.keyWindow?.layer.add(animation, forKey: nil)
            }
        }
    }

    private static var keyWindow: UIWindow? {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap(\.windows)
            .first { $0.isKeyWindow }
    }

    func pushView(route: Route) {
        navigationPath.append(route)
    }

    func popToRootView() {
        navigationPath = .init()
    }

    func popToSpecificView(k: Int) {
        navigationPath.removeLast(k)
    }
}
