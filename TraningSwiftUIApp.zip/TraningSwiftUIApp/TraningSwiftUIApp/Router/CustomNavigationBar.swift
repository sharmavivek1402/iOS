//
//  CustomNavigationBar.swift
//  FitFuluencerSwiftUI
//
//  Created by Vivek_Ios on 21/03/25.
//

import SwiftUI

struct CustomNavigationBar: View {
    let title: String
    let leftButtonImage: String
    let rightButtonText: String
    let onLeft: () -> Void
    let onRight: () -> Void

    var body: some View {
        HStack {
            // Dynamic Back Button with Image
            Button(action: onLeft) {
                Image(systemName: leftButtonImage)
                    .resizable()
                    .frame(width: 20, height: 20)
                    .foregroundColor(.black)
                    .padding()
            }

            Spacer()

            Text(title)
                .font(.headline)
                .foregroundColor(.black)

            Spacer()

            // Dynamic Skip Button with Text
            Button(action: onRight) {
                Text(rightButtonText)
                    .foregroundColor(.blue)
                    .padding()
            }
        }
        .padding()
        .background(Color.white)
       // .shadow(color: .gray.opacity(0.4), radius: 4, x: 0, y: 2)
    }
}
