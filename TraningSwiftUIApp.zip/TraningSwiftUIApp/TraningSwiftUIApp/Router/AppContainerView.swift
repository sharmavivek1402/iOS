//
//  AppContainerView.swift
//  FitFuluencerSwiftUI
//
//  Created by Vivek_Ios on 24/03/25.
//

import Foundation
import SwiftUI

struct AppContainerView: View {
    @ObservedObject var router: Router
    @State private var navigationPath = NavigationPath()
    var body: some View {
        NavigationStack(path: $router.navigationPath) {
            //LoginView()
            WelcomeView()
                .navigationDestination(for: Route.self) { route in
                    switch route {
                    case .login:
                        LoginView()
                    case .signUp:
                        SignupView()
                    case .welcome:
                        WelcomeView()
                    case .creteAccount:
                        CreteAccountView()
                    case .home:
                        HomeView(viewModel: HomeViewModel())
                        
                    }
                }
        }
        .environmentObject(router)
    }
}
