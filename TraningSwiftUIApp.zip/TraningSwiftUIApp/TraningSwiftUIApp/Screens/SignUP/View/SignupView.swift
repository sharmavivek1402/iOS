//
//  SignupView.swift
//  TraningSwiftUIApp
//
//  Created by Vivek_Ios on 25/04/26.
//

import SwiftUI

struct SignupView: View {
    
    @State private var email = ""
    @State private var firstName = ""
    @State private var LastName = ""
    @State private var age = ""
    @State private var mobleNO = ""
    @State private var rePassword = ""
    @State private var password = ""
    
    
    @EnvironmentObject private var router: Router
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    var body: some View {
            
            ZStack {
                Color(red: 239/255, green: 247/255, blue: 255/255)
                    .ignoresSafeArea()
                
                ScrollView {
                    
                    //MARK: - header Section
                    
                    VStack(alignment: .leading, spacing: 24) {
                        
                        //MARK: - header Section
                        VStack(alignment: .leading,spacing: 20){
                            
                            Text("Create Account")
                            
                                .font(.system(size: 32, weight: .bold))
                                .foregroundColor(.black)
                            
                            
                            Text("Fill The Dtails To Crete New Account")
                                .font(.system(size: 17, weight: .regular))
                                .foregroundColor(.black)
                        }.padding(.leading, 20)
                        
                        
                        //MARK: - textfields
                        VStack(alignment: .leading,spacing: 20){
                            
                            HStack {
                                Image("user")
                                    .foregroundColor(.gray)
                                TextField("Email", text: $email)
                                    .textFieldStyle(PlainTextFieldStyle())
                            }
                            .padding()
                            .background(Color(.systemGray6))
                            .cornerRadius(8)
                            
                            HStack {
                                Image("user")
                                    .foregroundColor(.gray)
                                TextField("First Name", text: $firstName)
                                    .textFieldStyle(PlainTextFieldStyle())
                            }
                            .padding()
                            .background(Color(.systemGray6))
                            .cornerRadius(8)
                            
                            
                            HStack {
                                Image("user")
                                    .foregroundColor(.gray)
                                TextField("Last Name", text: $LastName)
                                    .textFieldStyle(PlainTextFieldStyle())
                            }
                            .padding()
                            .background(Color(.systemGray6))
                            .cornerRadius(8)
                            
                            HStack {
                                Image("user")
                                    .foregroundColor(.gray)
                                TextField("Age", text: $age)
                                    .textFieldStyle(PlainTextFieldStyle())
                            }
                            .padding()
                            .background(Color(.systemGray6))
                            .cornerRadius(8)
                            
                            HStack {
                                Image("user")
                                    .foregroundColor(.gray)
                                TextField("Moble No", text: $mobleNO)
                                    .textFieldStyle(PlainTextFieldStyle())
                            }
                            .padding()
                            .background(Color(.systemGray6))
                            .cornerRadius(8)
                            
                            
                            HStack {
                                Image("key-square")
                                    .foregroundColor(.gray)
                                TextField("Password", text: $password)
                                    .textFieldStyle(PlainTextFieldStyle())
                            }
                            .padding()
                            .background(Color(.systemGray6))
                            .cornerRadius(8)
                            
                            HStack {
                                Image("key-square")
                                    .foregroundColor(.gray)
                                TextField("Conirm Password", text: $rePassword)
                                    .textFieldStyle(PlainTextFieldStyle())
                            }
                            .padding()
                            .background(Color(.systemGray6))
                            .cornerRadius(8)
                            
                            VStack(){
                                Button {
                                    router.pushView(route: .login)
                                } label: {
                                    Text("Submit")
                                        .font(.system(size: 17, weight: .bold))
                                        .frame(maxWidth: .infinity)
                                        .padding()
                                        .background(Color.blue)
                                        .foregroundColor(.black)
                                        .cornerRadius(8)
                                }
                                
                            }.padding(.top, 50) //Top space
                            
                            
                        }.padding(.all, 20) //all side space
                    }
                    
                    
                    
                } .padding(.top, 10)//to give space navigation tp scroll view
            }
        
        
    }
}

#Preview {
    SignupView()
        .environmentObject(Router())
}
