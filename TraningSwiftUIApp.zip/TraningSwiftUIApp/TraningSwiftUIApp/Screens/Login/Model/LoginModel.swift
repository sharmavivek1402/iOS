//
//  LoginModel.swift
//  TraningSwiftUIApp
//
//  Created by Vivek_Ios on 29/04/26.
//

import Foundation

struct  LoginResponse:Codable{
    let token: String
    let userName: String
}


struct LoginRequest:Codable{
    let email:String
    let password:String
//    init(email: String, password: String) {
//        self.email = email
//        self.password = password
//    }
}
