//
//  LoginView.swift
//  TraningSwiftUIApp
//
//  Created by Vivek_Ios on 25/04/26.
//

import SwiftUI
import Combine

struct LoginView: View {
    
    
    
    @StateObject private var viewModel = LoginViewModel()
    @EnvironmentObject private var router: Router
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    var body: some View {
        
        ZStack {
            Color(red: 239/255, green: 247/255, blue: 255/255)
                .ignoresSafeArea()
            
            
            ScrollView {
                
                //MARK: - header Section
                
                VStack(alignment: .leading, spacing: 24) {
                    
                    //MARK: - header Section
                    VStack(alignment: .leading,spacing: 20){
                        
                        Text("Login")
                        
                            .font(.system(size: 32, weight: .bold))
                            .foregroundColor(.black)
                        
                        
                        Text("Fill The Dtails To Login Account")
                            .font(.system(size: 17, weight: .regular))
                            .foregroundColor(.black)
                    }.padding(.leading, 20)
                    
                    
                    //MARK: - textfields
                    VStack(alignment: .leading,spacing: 20){
                        
                        HStack {
                            Image("user")
                                .foregroundColor(.gray)
                            TextField("Email", text: $email)
                                .textFieldStyle(PlainTextFieldStyle())
                        }
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                        
                        
                        HStack {
                            Image("key-square")
                                .foregroundColor(.gray)
                            TextField("Password", text: $password)
                                .textFieldStyle(PlainTextFieldStyle())
                        }
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                        
                        VStack(){
                            Button {
                                let loginRequest = LoginRequest(email: email, password: password)
//                                self.loginModel.loginRequestApiCall(request: loginRequest) { result in
//                                    switch result {
//                                    case .success(let response):
//                                        print("Login success: \(response)")
//                                        // Navigate to home or save token
//                                        DispatchQueue.main.async {
//                                            router.pushView(route: .home)
//                                        }
//                                    case .failure(let error):
//                                        print("Login failed: \(error.localizedDescription)")
//                                    }
//                                }
                                
                                Task {
                                        await viewModel.login()
                                    }
                                
                                
                                
                                // router.pushView(route: .home)
                            } label: {
                                Text("Login")
                                    .font(.system(size: 17, weight: .bold))
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.blue)
                                    .foregroundColor(.black)
                                    .cornerRadius(8)
                            }
                            
                        }.padding(.top, 50) //Top space
                        
                        
                    }.padding(.all, 20) //all side space
                }
                
            }.padding(.top, 10)
        }
        
        // .environmentObject(viewModel)
        
    }
}

//#Preview {
//    LoginView(loginRequest: LoginRequestModel(email: "", password: ""))
//
//}
