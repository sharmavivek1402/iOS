//
//   LoginViewModel.swift
//  TraningSwiftUIApp
//
//  Created by Vivek_Ios on 29/04/26.
//

import Foundation

//@Observable
//class LoginViewModel{
//    
//    private let service: LoginServiceProtocol
//    
//    func loginRequestApiCall(request:LoginRequestModel, completion: @escaping (Result<LoginModel, Error>) -> Void) {
//        
//            var model = LoginModel()
//            model.email = "vivek"
//            model.password = "12345"
//        //  Wrap in Result.success
//            completion(.success(model))
//        
//        
//        
//    }
//  
//}

// LoginViewModel.swift
// अब ViewModel किसी concrete class पर निर्भर नहीं है

import Foundation
import Combine

@MainActor
class LoginViewModel: ObservableObject {
    
    @Published var email: String = ""
    @Published var password: String = ""
    @Published var errorMessage: String = ""
    @Published var isLoading: Bool = false
    @Published var isLoggedIn: Bool = false
    
    private let service: LoginServiceProtocol
    
    // Dependency Injection via initializer
    init(service: LoginServiceProtocol) {
        self.service = service
    }
    
    var isEmailValid: Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        return NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluate(with: email)
    }
    
    var isPasswordValid: Bool {
        return password.count >= 6
    }
    
    var isFormValid: Bool {
        return isEmailValid && isPasswordValid
    }
    
    func login() async {
        guard isFormValid else {
            errorMessage = "ईमेल या पासवर्ड गलत है"
            return
        }
        
        isLoading = true
        errorMessage = ""
        
        do {
            let request = LoginRequest(email: email, password: password)
            let response = try await service.login(request: request)
            print("लॉगिन सफल: \(response)")
            isLoggedIn = true
        } catch {
            errorMessage = "लॉगिन असफल: \(error.localizedDescription)"
        }
        
        isLoading = false
    }
}
