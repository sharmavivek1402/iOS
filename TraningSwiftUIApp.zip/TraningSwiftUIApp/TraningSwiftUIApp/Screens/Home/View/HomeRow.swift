//
//  HomeRow.swift
//  TraningSwiftUIApp
//
//  Created by Vivek_Ios on 26/04/26.
//

import SwiftUI

struct HomeRow: View {
    
    let user: HomeModel
    let onDetailListTap: () -> Void
    let onCloseListTap: ((String) -> Void)
    
    @Binding var selectedUser: String   // child receives binding
    
    var body: some View {
        VStack(alignment: .leading){
            HStack{
                Image("football_profile")
                    .resizable()
                    .frame(width: 60, height: 60)
                
                VStack(alignment: .leading){
                    Text(user.name)
                        .font(.system(size: 17, weight: .bold))
                        .foregroundColor(.black)
                    Text(user.email)
                        .font(.system(size: 17, weight: .regular))
                        .foregroundColor(.black)
                }
                
                Spacer()
                VStack(){
                    Button {
                        
                        self.onCloseListTap(user.name)
                        selectedUser = user.name
                        
                    } label: {
                        Image("Cancel")
                        
                    }.buttonStyle(.plain)
                    Spacer()
                    
                }
            }
            
            VStack(){
                Button {
                    
                    self.onDetailListTap()
                   
                } label: {
                    Text("View More")
                        .font(.system(size: 17, weight: .bold))
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.black)
                        .cornerRadius(8)
                }.buttonStyle(.plain)
                
            }.padding(.top, 20)
           
        }//.padding(.leading, 20)
    }
}

