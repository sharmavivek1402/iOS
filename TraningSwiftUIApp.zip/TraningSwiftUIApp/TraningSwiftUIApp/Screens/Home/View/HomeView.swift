//
//  HomeView.swift
//  TraningSwiftUIApp
//
//  Created by Vivek_Ios on 26/04/26.
//

import SwiftUI

struct HomeView: View {
    @State var viewModel: HomeViewModel
    @State private var selectedUser: HomeModel?
    @State private var showDeleteAlert = false
    @State private var selectedUserName: String = ""
    var body: some View {
        ZStack {
            Color(red: 239/255, green: 247/255, blue: 255/255)
                .ignoresSafeArea()
            
            VStack(alignment: .leading, spacing: 10) {
                List(viewModel.homeModel) { item in
                    HomeRow(user: item,
                            onDetailListTap: {
                                print("View Button Clicked")
                            },
                            onCloseListTap: { name in
                             print(name)
                            selectedUser = item
                            showDeleteAlert = true
                            print("close Clicked")
                        
                    }, selectedUser: $selectedUserName)
                   
                    .contentShape(Rectangle())
                    .padding(.horizontal)
                    .onTapGesture {print("Cell  Clicked") }
                   
                }
                .listStyle(.plain)
                .navigationTitle("User List")
            }
        }
        // ✅ Attach alert once here
        .alert(isPresented: $showDeleteAlert) {
            Alert(
                title: Text("Delete User"),
                message: Text("Are you sure you want to delete this user from list?"),
                primaryButton: .destructive(Text("Delete")) {
                    if let userToDelete = selectedUser,
                       let index = viewModel.homeModel.firstIndex(where: { $0.id == userToDelete.id }) {
                        viewModel.homeModel.remove(at: index)
                    }
                },
                secondaryButton: .cancel()
            )
        }
    }
}


#Preview {
    
    // Preview requires a HomeViewModel because HomeView has a viewModel parameter in its initializer.
        // Passing HomeViewModel() here provides sample data so the preview can render correctly.
    HomeView(viewModel: HomeViewModel())
    
        
}
