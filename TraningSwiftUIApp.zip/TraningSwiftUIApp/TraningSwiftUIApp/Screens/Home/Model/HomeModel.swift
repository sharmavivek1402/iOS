//
//  HomeModel.swift
//  TraningSwiftUIApp
//
//  Created by Vivek_Ios on 26/04/26.
//

import Foundation

struct HomeModel:Identifiable{
    let id = UUID()
    let name:String
    let email:String
    let imageName:String
    
}
