//
//  HomeViewModel.swift
//  TraningSwiftUIApp
//
//  Created by Vivek_Ios on 26/04/26.
//

import Foundation
import Combine


class HomeViewModel: ObservableObject {
    
    @Published var homeModel: [HomeModel] = []
    
    init() {
        loadUsers()
    }
    
    func loadUsers() {
        homeModel = [
            HomeModel(name: "Aman Singh", email: "aman@gmail.com", imageName: "person.circle"),
            HomeModel(name: "Rahul Kumar", email: "rahul@gmail.com", imageName: "person.circle"),
            HomeModel(name: "Priya Sharma", email: "priya@gmail.com", imageName: "person.circle")
        ]
    }
}
