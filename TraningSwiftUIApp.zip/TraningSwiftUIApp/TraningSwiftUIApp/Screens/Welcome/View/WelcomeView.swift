//
//  WelcomeView.swift
//  TraningSwiftUIApp
//
//  Created by Vivek_Ios on 25/04/26.
//

import SwiftUI

struct WelcomeView: View {
    
    @EnvironmentObject private var router: Router
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    var body: some View {
        
        ZStack{
            
            Image("Background")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
            
            
            VStack(spacing: 40){
                
                VStack(){
                    
                    Text("Welcome To")
                    
                        .font(.system(size: 32, weight: .bold))
                        .foregroundColor(.black)
                    
                    
                    Text("Jon Our Community")
                        .font(.system(size: 17, weight: .regular))
                        .foregroundColor(.white)
                }
                
                VStack(spacing: 20){
                    Button {
                        router.pushView(route: .signUp)
                       
                        
                    }label:{
                        Text("Sign Up")
                            .font(.system(size: 17, weight: .bold))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, maxHeight: 40)
                            .padding(.horizontal, 20)                    //  20 points margin from both sides
                            .background(Color.white)   //  Background color
                            .foregroundColor(.white)  //  Text color
                            .cornerRadius(8)          //  Rounded corners
                    }
                    
                    
                    
                    Button {
                        router.pushView(route: .login)
                        
                    }label:{
                        Text("Login")
                            .font(.system(size: 17, weight: .bold))
                            .foregroundColor(.black)
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, maxHeight: 40)
                            .padding(.horizontal, 20)
                            .background(Color.white)   //  Background color
                            .foregroundColor(.white)  //  Text color
                            .cornerRadius(8)          //  Rounded corners
                    }
                }
                
                .padding(.horizontal, 20)
            }
                       
        }
    }
}

#Preview {
    WelcomeView()
}
