//
//  CreteAccountView.swift
//  TraningSwiftUIApp
//
//  Created by Vivek_Ios on 25/04/26.
//

import SwiftUI

struct CreteAccountView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    CreteAccountView()
}
