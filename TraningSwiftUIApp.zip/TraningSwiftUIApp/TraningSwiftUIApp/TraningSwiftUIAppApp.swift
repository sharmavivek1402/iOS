//
//  TraningSwiftUIAppApp.swift
//  TraningSwiftUIApp
//
//  Created by Vivek_Ios on 25/04/26.
//

import SwiftUI

@main
struct TraningSwiftUIAppApp: App {
    @StateObject private var router = Router()

    var body: some Scene {
        WindowGroup {
            AppContainerView(router: router)
        }
    }
}
